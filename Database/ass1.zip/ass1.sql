-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2023 at 05:06 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ass1`
--

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `fname` varchar(20) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `filesize` int(11) NOT NULL,
  `extension` varchar(5) DEFAULT NULL,
  `owner` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`fname`, `lname`, `filesize`, `extension`, `owner`) VALUES
('hello', 'hello.txt', 7, '.txt', 2886731930),
('nha', './publish_fetch/hello.txt', 32, '.txt', 2886732019),
('share1', 'share_file\\hello.txt', 23, '.txt', 2886731930),
('share1', 'libclient.py', 6458, '.py', 2886732016),
('share2', 'share_file\\dbs.pdf', 736392, '.pdf', 2886731930);

-- --------------------------------------------------------

--
-- Table structure for table `peer`
--

CREATE TABLE `peer` (
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `IPAddress` int(10) UNSIGNED NOT NULL,
  `port` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `peer`
--

INSERT INTO `peer` (`username`, `password`, `IPAddress`, `port`) VALUES
('phuongnha', '12345', 2886731930, 9999),
('nhi', 'nhinhi', 2886732016, 9999),
('nha', 'nhakhung', 2886732019, 9999),
('nhanha', 'nhanhanha', 3232270813, 9999);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`fname`,`owner`) USING BTREE,
  ADD KEY `FK_owner_IPAddress` (`owner`);

--
-- Indexes for table `peer`
--
ALTER TABLE `peer`
  ADD PRIMARY KEY (`IPAddress`),
  ADD UNIQUE KEY `IPAddress` (`IPAddress`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `files`
--
ALTER TABLE `files`
  ADD CONSTRAINT `FK_owner_IPAddress` FOREIGN KEY (`owner`) REFERENCES `peer` (`IPAddress`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
